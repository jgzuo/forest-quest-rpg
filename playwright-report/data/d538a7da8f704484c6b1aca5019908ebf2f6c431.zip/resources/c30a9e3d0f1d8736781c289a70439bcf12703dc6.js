/**
 * SceneManager - 场景管理器
 * 负责管理游戏场景的加载和切换
 */
class SceneManager {
    constructor(scene) {
        this.scene = scene;
        this.currentScene = 'town';
        this.playerSpawnPoint = { x: 400, y: 300 };
        this.isTransitioning = false;  // 防止场景切换时的频闪
        this.lastTeleportTime = 0;  // 记录上次传送时间，防止死循环
        this.TELEPORT_COOLDOWN = 2000;  // 传送冷却时间（毫秒）

        // 新增：防止出生点在传送区域内立即触发返回
        this.recentlyTeleported = false;  // 是否刚传送过来
        this.teleportCounter = 0;  // 传送点计数器，用于生成唯一ID
        this.activeTeleports = [];  // 存储所有传送点引用
    }

    /**
     * 切换到指定场景
     * @param {string} sceneName - 场景名称 ('town', 'forest', 'cave')
     * @param {object} spawnPoint - 玩家出生点 {x, y}
     */
    switchScene(sceneName, spawnPoint = null) {
        const now = Date.now();

        // 防止重复切换场景
        if (this.isTransitioning) {
            console.log('⏸️ 场景切换中，忽略重复调用');
            return;
        }

        // 防止传送死循环（检查冷却时间）
        if (now - this.lastTeleportTime < this.TELEPORT_COOLDOWN) {
            console.log(`⏸️ 传送冷却中，还需等待 ${this.TELEPORT_COOLDOWN - (now - this.lastTeleportTime)}ms`);
            return;
        }

        this.lastTeleportTime = now;
        this.isTransitioning = true;
        console.log(`🔄 切换场景: ${this.currentScene} → ${sceneName}`);

        // 暂停游戏，防止敌人攻击和玩家移动
        this.scene.physics.pause();

        // 保存当前场景信息
        const previousScene = this.currentScene;

        // 设置新场景
        this.currentScene = sceneName;

        // 设置玩家出生点
        if (spawnPoint) {
            this.playerSpawnPoint = spawnPoint;
        }

        // 创建淡出效果
        this.createTransition(() => {
            // 清理当前场景对象
            this.cleanupScene();

            // 加载新场景
            this.loadScene(sceneName);

            // 更新场景名称显示
            if (this.scene.updateSceneIndicator) {
                this.scene.updateSceneIndicator(sceneName);
            }

            // 设置玩家位置
            if (this.scene.player) {
                this.scene.player.setPosition(
                    this.playerSpawnPoint.x,
                    this.playerSpawnPoint.y
                );
                console.log(`📍 玩家位置设置为: (${this.playerSpawnPoint.x}, ${this.playerSpawnPoint.y})`);
            }

            // 自动保存游戏
            if (this.scene.saveManager) {
                console.log('💾 [Scene Switch] Triggering auto-save...');
                const saveSuccess = this.scene.saveManager.autoSave();
                console.log(`💾 [Scene Switch] Auto-save result: ${saveSuccess}`);
            } else {
                console.warn('⚠️ [Scene Switch] SaveManager not found!');
            }

            // 淡入效果（从黑色淡入到正常，更快）
            this.scene.cameras.main.resetFX();
            this.scene.cameras.main.fadeIn(300, 0, 0, 0);

            // 标记玩家刚传送过来，防止立即触发返回传送
            this.recentlyTeleported = true;
            console.log('🚀 玩家刚传送过来，需要离开传送区域后再回来才能触发返回');

            // 场景切换完成后，重置标志（fadeOut 300ms + fadeIn 300ms = 600ms后）
            this.scene.time.delayedCall(600, () => {
                this.isTransitioning = false;
                // 恢复游戏物理
                this.scene.physics.resume();
                console.log('✅ 场景切换完成，物理系统已恢复');
            });
        });
    }

    /**
     * 创建场景过渡效果
     */
    createTransition(callback) {
        // 淡出
        this.scene.cameras.main.fade(300, 0, 0, 0);

        // 等待淡出完成后执行回调
        this.scene.time.delayedCall(300, () => {
            callback();
        });
    }

    /**
     * 清理当前场景对象
     */
    cleanupScene() {
        const objectsToRemove = [];
        let removedCount = 0;

        this.scene.children.each((child) => {
            // 保留玩家对象、场景名称文本、以及相机相关的Graphics
            if (child !== this.scene.player &&
                child !== this.scene.sceneNameText &&
                child.type !== 'Graphics' &&
                child.type !== 'Text') {
                objectsToRemove.push(child);
            }
        });

        // 销毁所有标记的对象
        objectsToRemove.forEach(obj => {
            if (obj && obj.active) {
                obj.destroy();
                removedCount++;
            }
        });

        // 清空传送点数组，因为旧场景的传送点已被销毁
        const previousTeleportCount = this.activeTeleports.length;
        this.activeTeleports = [];

        // 清理Boss（如果存在）
        if (this.boss) {
            this.boss.destroy();
            this.boss = null;
            console.log('👑 Boss已清理');
        }

        console.log(`🧹 场景清理完成: 移除了 ${removedCount} 个对象，${previousTeleportCount} 个传送点`);
    }

    /**
     * 加载场景
     */
    loadScene(sceneName) {
        // 切换场景音乐
        if (this.scene.audioManager) {
            this.scene.audioManager.changeSceneMusic(sceneName);
        }

        switch (sceneName) {
            case 'town':
                this.loadTownScene();
                break;
            case 'forest':
                this.loadForestScene();
                break;
            case 'cave':
                this.loadCaveScene();
                break;
            default:
                console.warn(`未知场景: ${sceneName}`);
        }
    }

    /**
     * 加载小镇场景
     */
    loadTownScene() {
        console.log('🏘️ 加载小镇场景');

        // 创建草地背景
        const bg = this.scene.add.rectangle(400, 300, 800, 600, 0x4a7c59);
        bg.setDepth(-100);

        // 添加装饰性树木
        const treePositions = [
            { x: 100, y: 100 }, { x: 700, y: 100 },
            { x: 100, y: 500 }, { x: 700, y: 500 },
            { x: 400, y: 100 }, { x: 400, y: 500 }
        ];

        treePositions.forEach(pos => {
            this.scene.add.image(pos.x, pos.y, 'tree-orange').setScale(3).setDepth(-50);
        });

        // 添加NPC（村长）
        this.createNPC('elder', 400, 200, '村长');

        // 添加NPC（商人）
        this.createNPC('merchant', 600, 200, '商人');

        // 添加宝箱
        this.createChest(200, 400);
        this.createChest(600, 450);

        // 添加传送点（到森林）
        this.createTeleport('forest', 700, 300, '→ 森林', { x: 100, y: 300 });

        // 添加建筑物
        this.createBuilding(200, 150, 120, 100, 0x8b4513); // 村长屋
        this.createBuilding(600, 150, 100, 80, 0xa0522d);   // 商店

        console.log('✅ 小镇场景加载完成');
    }

    /**
     * 加载森林场景
     */
    loadForestScene() {
        console.log('🌲 加载森林场景');

        // 创建森林背景
        const bg = this.scene.add.rectangle(400, 300, 800, 600, 0x2d5a27);
        bg.setDepth(-100);
        console.log(`✅ 森林背景创建完成: 颜色=0x2d5a27(深绿色), depth=-100`);

        // 添加大量树木
        for (let i = 0; i < 30; i++) {
            const x = Phaser.Math.Between(50, 750);
            const y = Phaser.Math.Between(50, 550);
            const treeType = Phaser.Math.RND.pick(['tree-orange', 'tree-pink', 'tree-dried']);

            const tree = this.scene.add.image(x, y, treeType).setScale(3);
            tree.setDepth(Phaser.Math.Between(-50, -10));
        }
        console.log('✅ 添加了30棵树木');

        // 添加岩石和灌木
        for (let i = 0; i < 10; i++) {
            const x = Phaser.Math.Between(100, 700);
            const y = Phaser.Math.Between(100, 500);

            if (Math.random() > 0.5) {
                this.scene.add.image(x, y, 'rock').setScale(2).setDepth(-20);
            } else {
                this.scene.add.image(x, y, 'bush').setScale(2).setDepth(-20);
            }
        }
        console.log('✅ 添加了10个岩石/灌木');

        // 添加传送点（回到小镇）
        this.createTeleport('town', 50, 300, '→ 小镇', { x: 650, y: 300 });

        // 添加传送点（到洞穴）
        this.createTeleport('cave', 700, 500, '→ 洞穴', { x: 100, y: 100 });

        // 在森林中生成一些敌人
        this.spawnEnemiesInForest();

        console.log('✅ 森林场景加载完成');
    }

    /**
     * 加载洞穴场景
     */
    loadCaveScene() {
        console.log('⛰️ 加载洞穴场景');

        // 创建洞穴背景
        const bg = this.scene.add.rectangle(400, 300, 800, 600, 0x1a1a2e);
        bg.setDepth(-100);

        // 添加洞穴装饰（岩石）
        for (let i = 0; i < 20; i++) {
            const x = Phaser.Math.Between(50, 750);
            const y = Phaser.Math.Between(50, 550);
            this.scene.add.image(x, y, 'rock').setScale(2.5).setDepth(-30);
        }

        // 添加传送点（回到森林）
        this.createTeleport('forest', 100, 100, '→ 森林', { x: 700, y: 500 });

        // 在洞穴中生成更强的敌人
        // this.spawnEnemiesInCave(); // Boss战中不生成小怪

        // 生成Boss
        this.spawnBoss('treant_king', 400, 300);

        console.log('✅ 洞穴场景加载完成');
    }

    /**
     * 创建NPC
     */
    createNPC(id, x, y, name) {
        // 二维sprite sheet：横向4个NPC，纵向3个方向
        // Phaser从左到右、从上到下扫描，帧号 = 方向行号 * 4 + NPC列号
        const npcIndex = id === 'elder' ? 0 : 1;  // 村长=第0列, 商人=第1列
        const directionIndex = Math.floor(Math.random() * 3);  // 随机选择一个方向(0-2)
        const frameIndex = directionIndex * 4 + npcIndex;  // 修正帧号计算

        const npc = this.scene.add.image(x, y, 'npc', frameIndex).setScale(3);
        npc.setData('type', 'npc');
        npc.setData('id', id);
        npc.setData('name', name);

        console.log(`👤 创建NPC: ${name} at (${x}, ${y}), 使用spritesheet第${npcIndex}号NPC，第${directionIndex}个方向（帧${frameIndex}）`);

        // 添加对话提示
        const hint = this.scene.add.text(x, y - 30, 'E 对话', {
            font: '12px Arial',
            fill: '#ffff00',
            stroke: '#000000',
            strokeThickness: 3
        }).setOrigin(0.5);

        // NPC交互区域
        const interactionZone = this.scene.add.zone(x, y, 60, 60);
        interactionZone.setData('npc', npc);
        interactionZone.setData('hint', hint);

        // 设置物理体
        this.scene.physics.add.existing(interactionZone);
        interactionZone.body.setAllowGravity(false);
        interactionZone.body.setImmovable(true);

        // 碰撞检测
        this.scene.physics.add.overlap(
            this.scene.player,
            interactionZone,
            () => this.showInteractionHint(hint)
        );
    }

    /**
     * 显示交互提示
     */
    showInteractionHint(hint) {
        if (hint && hint.active) {
            hint.setVisible(true);

            // 3秒后隐藏
            this.scene.time.delayedCall(3000, () => {
                if (hint.active) hint.setVisible(false);
            });
        }
    }

    /**
     * 创建传送点
     */
    createTeleport(targetScene, x, y, label, spawnPoint) {
        // 为每个传送点生成唯一ID
        const teleportId = `teleport_${this.teleportCounter++}`;

        // 传送区域
        const teleport = this.scene.add.zone(x, y, 60, 60);
        teleport.setData('type', 'teleport');
        teleport.setData('teleportId', teleportId);
        teleport.setData('targetScene', targetScene);
        teleport.setData('spawnPoint', spawnPoint);
        teleport.setData('lastTriggerTime', 0); // 为每个传送点单独记录触发时间

        // 视觉标识
        const graphics = this.scene.add.graphics();
        graphics.fillStyle(0x4facfe, 0.3);
        graphics.fillCircle(x, y, 30);
        graphics.setDepth(-5);

        // 传送标签
        const text = this.scene.add.text(x, y, label, {
            font: '14px Arial',
            fill: '#4facfe',
            stroke: '#000000',
            strokeThickness: 4
        }).setOrigin(0.5);

        // 设置物理体
        this.scene.physics.add.existing(teleport);
        teleport.body.setAllowGravity(false);
        teleport.body.setImmovable(true);

        // 碰撞检测 - 防止刚传送过来就立即触发返回
        this.scene.physics.add.overlap(
            this.scene.player,
            teleport,
            () => {
                // 关键修复：如果玩家刚传送过来，不触发传送
                if (this.recentlyTeleported) {
                    console.log(`⏸️ 玩家刚传送过来，暂时不触发 ${label}，请先离开传送区域再回来`);
                    return;
                }

                const now = Date.now();
                const lastTime = teleport.getData('lastTriggerTime');
                const cooldown = 3000; // 3秒冷却时间

                // 检查是否在冷却时间内
                if (now - lastTime < cooldown) {
                    return; // 在冷却中，不触发传送
                }

                // 检查是否正在进行场景切换
                if (this.isTransitioning) {
                    return; // 正在切换，不触发传送
                }

                // 更新这个传送点的触发时间
                teleport.setData('lastTriggerTime', now);

                // 执行场景切换
                console.log(`🚀 触发传送: ${label} → ${targetScene}`);
                this.switchScene(targetScene, spawnPoint);
            }
        );

        // 将传送点保存到数组中，用于后续检查玩家是否离开
        this.activeTeleports.push(teleport);

        console.log(`🚪 创建传送点: ${label} → ${targetScene} (ID: ${teleportId})`);
    }

    /**
     * 检查玩家是否离开传送区域（每帧调用）
     * 这个方法应该在GameScene的update()中调用
     */
    checkTeleportExit() {
        // 如果玩家没有刚传送过来，不需要检查
        if (!this.recentlyTeleported) {
            return;
        }

        // 检查玩家是否离开了所有传送区域
        const playerBounds = this.scene.player.getBounds();
        let isInsideAnyTeleport = false;

        for (const teleport of this.activeTeleports) {
            const teleportBounds = teleport.getBounds();
            if (Phaser.Geom.Rectangle.Overlaps(playerBounds, teleportBounds)) {
                isInsideAnyTeleport = true;
                break;
            }
        }

        // 如果玩家不在任何传送区域内，清除标志
        if (!isInsideAnyTeleport) {
            this.recentlyTeleported = false;
            console.log(`✅ 玩家已离开传送区域，现在可以重新触发传送了`);
        }
    }

    /**
     * 创建建筑物
     */
    createBuilding(x, y, width, height, color) {
        const building = this.scene.add.rectangle(x, y, width, height, color);
        building.setStrokeStyle(4, 0x000000);
        building.setDepth(-20);

        // 添加文字标签
        const label = this.scene.add.text(x, y, '建筑', {
            font: '12px Arial',
            fill: '#ffffff'
        }).setOrigin(0.5);

        console.log(`🏠 创建建筑物 at (${x}, ${y})`);
    }

    /**
     * 创建宝箱
     */
    createChest(x, y) {
        // 创建宝箱图形
        const chest = this.scene.add.rectangle(x, y, 30, 25, 0xdaa520);
        chest.setStrokeStyle(3, 0x8b4513);
        chest.setDepth(-10);

        // 添加宝箱装饰
        const lock = this.scene.add.circle(x, y, 4, 0xffd700);
        lock.setDepth(-9);

        // 设置宝箱数据
        chest.setData('type', 'chest');
        chest.setData('opened', false);

        // 添加交互提示
        const hint = this.scene.add.text(x, y - 20, 'E 打开', {
            font: '10px Arial',
            fill: '#ffd700',
            stroke: '#000000',
            strokeThickness: 2
        }).setOrigin(0.5);
        hint.setVisible(false);

        // 创建交互区域
        const zone = this.scene.add.zone(x, y, 50, 50);
        this.scene.physics.add.existing(zone);
        zone.body.setAllowGravity(false);
        zone.body.setImmovable(true);

        // 显示提示
        this.scene.physics.add.overlap(
            this.scene.player,
            zone,
            () => {
                if (!chest.getData('opened')) {
                    hint.setVisible(true);
                    this.scene.time.delayedCall(3000, () => {
                        if (hint.active) hint.setVisible(false);
                    });
                }
            }
        );

        console.log(`🎁 创建宝箱 at (${x}, ${y})`);
    }

    /**
     * 在森林中生成敌人
     */
    spawnEnemiesInForest() {
        // 清除现有敌人
        if (this.scene.enemies) {
            this.scene.enemies.clear(true, true);
        }

        this.scene.enemies = this.scene.physics.add.group();

        // 获取玩家当前位置，确保敌人生成在安全距离外
        const playerX = this.playerSpawnPoint.x || 400;
        const playerY = this.playerSpawnPoint.y || 300;
        const safeDistance = 200; // 安全距离：敌人至少距离玩家200像素

        // 生成鼹鼠（远离玩家）
        for (let i = 0; i < 5; i++) {
            let x, y, distance;
            let attempts = 0;
            do {
                x = Phaser.Math.Between(150, 650);
                y = Phaser.Math.Between(100, 500);
                distance = Phaser.Math.Distance.Between(x, y, playerX, playerY);
                attempts++;
            } while (distance < safeDistance && attempts < 10);

            this.spawnEnemy('mole', x, y);
            console.log(`🐹 生成鼹鼠 at (${x}, ${y}), 距离玩家 ${Math.round(distance)}px`);
        }

        // 生成树妖（远离玩家）
        for (let i = 0; i < 3; i++) {
            let x, y, distance;
            let attempts = 0;
            do {
                x = Phaser.Math.Between(200, 600);
                y = Phaser.Math.Between(150, 450);
                distance = Phaser.Math.Distance.Between(x, y, playerX, playerY);
                attempts++;
            } while (distance < safeDistance && attempts < 10);

            this.spawnEnemy('treant', x, y);
            console.log(`🌳 生成树妖 at (${x}, ${y}), 距离玩家 ${Math.round(distance)}px`);
        }

        console.log('👹 森林敌人生成完成');
    }

    /**
     * 在洞穴中生成敌人
     */
    spawnEnemiesInCave() {
        // 清除现有敌人
        if (this.scene.enemies) {
            this.scene.enemies.clear(true, true);
        }

        this.scene.enemies = this.scene.physics.add.group();

        // 生成更多树妖
        for (let i = 0; i < 6; i++) {
            const x = Phaser.Math.Between(150, 650);
            const y = Phaser.Math.Between(100, 500);
            this.spawnEnemy('treant', x, y);
        }

        console.log('👹 洞穴敌人生成完成');
    }

    /**
     * 生成单个敌人
     */
    spawnEnemy(type, x, y) {
        let enemy;
        let hp, attack, speed, xp, gold;

        if (type === 'mole') {
            enemy = this.scene.enemies.create(x, y, 'mole-idle-front');
            enemy.setScale(3);
            hp = 30;
            attack = 5;
            speed = 50;
            xp = 15;
            gold = 10;
        } else if (type === 'treant') {
            enemy = this.scene.enemies.create(x, y, 'treant-idle-front');
            enemy.setScale(3);
            hp = 80;
            attack = 12;
            speed = 30;
            xp = 50;
            gold = 25;
        }

        enemy.setData('type', type);
        enemy.setData('hp', hp);
        enemy.setData('maxHp', hp);
        enemy.setData('attack', attack);
        enemy.setData('speed', speed);
        enemy.setData('xp', xp);
        enemy.setData('gold', gold);
        enemy.setData('lastHitTime', 0); // 初始化攻击冷却时间

        // 创建血条背景
        const hpBarWidth = 40;
        const hpBarHeight = 4;
        const hpBarX = x;
        const hpBarY = y - 25;

        const hpBarBg = this.scene.add.rectangle(hpBarX, hpBarY, hpBarWidth, hpBarHeight, 0x000000);
        hpBarBg.setOrigin(0.5);
        hpBarBg.setDepth(100);
        // 血条跟随敌人移动，所以不设置setScrollFactor(0)

        // 创建血条前景（红色）
        const hpBar = this.scene.add.rectangle(hpBarX, hpBarY, hpBarWidth, hpBarHeight, 0xff0000);
        hpBar.setOrigin(0.5);
        hpBar.setDepth(101);

        // 保存血条引用到enemy对象
        enemy.hpBar = hpBar;
        enemy.hpBarBg = hpBarBg;

        console.log(`👹 生成敌人: ${type} at (${x}, ${y}), HP=${hp}, Attack=${attack}`);
    }

    /**
     * 生成Boss
     */
    spawnBoss(type, x, y) {
        console.log(`👑 生成Boss: ${type} at (${x}, ${y})`);

        // 创建Boss实例
        const boss = new Boss(this.scene, type, x, y);
        boss.create();

        // 激活Boss血条
        boss.showHealthBar();

        // 保存Boss引用到SceneManager
        this.boss = boss;

        console.log(`✅ Boss生成完成: ${type}`);
    }

    /**
     * 获取当前场景名称
     */
    getCurrentScene() {
        return this.currentScene;
    }

    /**
     * 获取场景信息（用于调试）
     */
    getSceneInfo() {
        return {
            currentScene: this.currentScene,
            playerPosition: this.scene.player ? {
                x: Math.round(this.scene.player.x),
                y: Math.round(this.scene.player.y)
            } : null,
            spawnPoint: this.playerSpawnPoint,
            isTransitioning: this.isTransitioning,
            recentlyTeleported: this.recentlyTeleported,
            activeTeleportsCount: this.activeTeleports.length,
            enemiesCount: this.enemies ? this.enemies.getChildren().length : 0
        };
    }
}
